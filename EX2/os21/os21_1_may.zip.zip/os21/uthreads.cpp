#include <map>
#include <queue>
#include <cstring>
#include "uthreads.h"


#define SETITIMER_ERR std::ostream(nullptr)
int totalQuantums;
std::map<int, Thread *> all_threads;
std::map<int, Thread *> blocked_threads;
std::deque<Thread *> ready_threads;
std::priority_queue<int, std::vector<int>, std::greater<int> > available_id_pq;

//int used_indexes[MAX_THREAD_NUM];

Thread *running;
struct sigaction sa;
struct itimerval timer;

//
//struct{
//    int id;
//    std::stack MAX_THREAD_NUM
//};


/*
 * Description: This function initializes the thread library.
 * You may assume that this function is called before any other thread library
 * function, and that it is called exactly once. The input to the function is
 * the length of a quantum in micro-seconds. It is an error to call this
 * function with non-positive quantum_usecs.
 * Return value: On success, return 0. On failure, return -1.
*/
void timer_handler(int sig)
{
    //gotit = 1;
    std::cout << "Time Handler called\n" << std::endl;
    running->save_dataFrame();
    running->set_state(State::Ready);

}

int scheduler()
{
    State cur_state;
    int return_flag = 0;
    totalQuantums++;
    if (ready_threads.size() == 0)
    {
        running->add_quantum();
    }
    else
    {

        Thread *next_ready = ready_threads.front();
        ready_threads.pop_front();

        //handle terminated - running is nullptr
        if (running == nullptr)
        {

            return_flag = 0;

        }

        else
        {
            cur_state = running->get_state();

            switch (cur_state)
            {

                case State::Ready:

                    ready_threads.push_back(running);

                    return_flag = sigsetjmp(*(running->get_env()),
                                            1);  // look at brian informative error
                    break;

                case State::Blocked:

                    blocked_threads[running->get_id()] = running;

                    return_flag = sigsetjmp(*(running->get_env()),
                                            1);  // look at brian informative error


                    //
                    break;


                default:
                    //Throw Error -  not a state

                    break;
            }


            if (return_flag == 0)
            {
                running = next_ready;
                running->set_state(State::Running);
                //add total quantoms and the specific running thread.
                //  totalQuantums++;
                running->add_quantum();
                siglongjmp(*(running->get_env()), 1); // look at brian informative error


            }


        }
    }
    if (setitimer(ITIMER_VIRTUAL, &timer, nullptr))
    { // look at brian informative error
        printf("setitimer error.");
    }


}

int uthread_init(int quantum_usecs)
{
    Thread *mainThread;
    int fail_succeed = 0;
    if (quantum_usecs < 0)
    {
        fail_succeed = -1;
        // return error message
    }
    else
    {
        all_threads = *new std::map<int, Thread *>();
        blocked_threads = *new std::map<int, Thread *>();
        ready_threads = *new std::deque<Thread *>();

        sa.sa_handler = &timer_handler;

        // Configure the timer to expire after 1 sec... */
        timer.it_value.tv_sec = 0;        // first time interval, seconds part
        timer.it_value.tv_usec = quantum_usecs;        // first time interval, microseconds part

        // configure the timer to expire every 3 sec after that.
        timer.it_interval.tv_sec = 0;    // following time intervals, seconds part
        timer.it_interval.tv_usec = quantum_usecs;    // following time intervals, microseconds part

        //initialize available ID
        for (int i = 1; i < MAX_THREAD_NUM; i++)
        {
            available_id_pq.push(i);
        }

        // create main thread 0

        mainThread = new Thread();
        all_threads[0] = mainThread;
        scheduler();

        // add signal interrupt block bullshit, and resume interrupt bullshit.

        return fail_succeed;

    }

    return fail_succeed;
    // activate timer - itimer line 31

    // create thread 0 from main - without pc line
    // point to a function when the signal occures - line 26

}
//void add_all_quantoms(Thread* thread){
//    totalQuantums++;
//    thread->add_quantum();
//}


int uthread_spawn(void (*f)())
{
    // block timer -----!!!
    Thread *spawn_thread;
    int thread_id = available_id_pq.top();
    int return_num = thread_id;
    if (thread_id == MAX_THREAD_NUM)
    {
        return_num = -1;
        // araise error
    }
    else
    {
        available_id_pq.pop();
        spawn_thread = new Thread(thread_id, f);
        all_threads[thread_id] = spawn_thread;
        ready_threads.push_back(spawn_thread);
//        return thread_id;
        //resume timer ----!!!

    }
    return return_num;


    // call a function that finds next available space - sorted by id
    // create new thread, and add it to the end of ready list


    // sigset - maybe move from Thread
}


int uthread_terminate(int tid)
{

    if (tid == 0)
    {
        terminate_main_thread();
        //terminate_main_thread
    }


    if (all_threads.count(tid) == 0) // id not found
    {

        // araise error

    }
    else
    {
        // id found, lets kill it.
        Thread *t_thread;
        t_thread = all_threads[tid];
        if (t_thread == running)
        {

            all_threads.erase(tid);
            t_thread->clean_thread();
            running = nullptr;
            available_id_pq.push(tid);
            scheduler();

        }
        else
        {
            all_threads.erase(tid);

            if (blocked_threads.count(tid) == 0)
            {
                int ready_thread_idx;
                for (ready_thread_idx = 0;
                     ready_thread_idx < ready_threads.size(); ready_thread_idx++)
                {
                    if (ready_threads[ready_thread_idx] == t_thread)
                    {
                        break;
                    }
                }
                ready_threads.erase(ready_threads.begin() + ready_thread_idx);
            }
            else
            {
                blocked_threads.erase(tid);
            }
            // remove dependencies
            t_thread->clean_thread();


        }

        std::vector<int> dependant_lst = t_thread->get_depend_vec();
        Thread *tmp;
        for(std::vector<int>::size_type i = 0; i != dependant_lst.size(); i++) {
            tmp = all_threads[dependant_lst[i]];

            tmp->set_sync(false);

            block_sync_decision(tmp);




        }


    }

    // delete stack and dependancy
    // remove from all_threads etc
    // resume all synced - by order
    // term main - exit(0)
    // if terminate is the running - go to scheduler

    // in scheduler -    reset timer, ++ quantums and take first


}
void block_sync_decision(Thread* thread){
if(!(thread->is_block()|thread->is_sync())) {    // not sync & not blocked

    thread-> set_state(State::Ready);
    ready_threads.push_back(thread);
    blocked_threads.erase(thread->get_id());


}

}


int uthread_block(int tid)
{
    // block running


}

void terminate_main_thread()
{

    for (auto &all_thread : all_threads)
    {
        all_thread.second->clean_thread();

    }
    all_threads.clear();
    blocked_threads.clear();
    ready_threads.clear();
    delete &sa;
    delete &timer;
    exit(0);


}

//
// Created by omerrubi on 4/30/18.
//

#include "main.h"
#include "uthreads.h"
int main(){

    uthread_init(100);


}